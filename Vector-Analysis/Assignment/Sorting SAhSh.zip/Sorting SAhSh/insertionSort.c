#include <stdio.h>
int main()
{
    int n, i, j, t, k, flag;

    printf("Enter the number of elements you want: ");
    scanf("%d", &n);
    int array[n];
    printf("Array elements: ");

    for (i = 0; i < n; i++){
        scanf("%d", &array[i]);
    }


    for (i = 1; i <= n - 1; i++) {
        t = array[i];
        flag = 0;

        for (j = i - 1; j >= 0; j--) {
            if (array[j] > t) {
                array[j + 1] = array[j];
                flag = 1;
            }
            else {
                break;
            }
        }
        if (flag)
            array[j + 1] = t;
        for (k = 0; k <= n - 1; k++) {
            printf("%d ", array[k]);
        }
        printf("\n");
    }

    printf("Sorted Array: ");

    for (i = 0; i <= n - 1; i++) {
        printf("%d  ", array[i]);
    }

    return 0;
}

