#include <stdio.h>
int main()
{
    int n, i, j, position, t;

    printf("Enter the number of elements you want: ");
    scanf("%d", &n);
    int array[n];
    printf("Array Elements: ", n);

    for (i = 0; i < n; i++){
        scanf("%d", &array[i]);
    }

    for (i = 0; i < (n - 1); i++)
    {
        position = i;

        for (j = i + 1; j < n; j++)
        {
            if (array[j] < array[position] )
            position = j;
        }
        if (position != i)
        {
            t = array[i];
            array[i] = array[position];
            array[position] = t;
        }
    }

    printf("Sorted Array: ");

    for (i = 0; i < n; i++){
        printf("%d ", array[i]);
    }

    return 0;
}
