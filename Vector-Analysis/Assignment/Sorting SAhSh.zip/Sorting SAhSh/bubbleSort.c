#include <stdio.h>
int main()
{
    int n, i, j, swap,k;
    printf("Enter the number of elements you want in array: ");
    scanf("%d", &n);
    int array[n];

    printf("Array elements: ");

    for (i = 0; i < n; i++){
        scanf("%d", &array[i]);
    }

    for (i = 0 ; i < n - 1; i++)
    {
        for (j = 0 ; j < n - i - 1; j++)
        {
            if (array[j] > array[j+1])
            {
                swap       = array[j];
                array[j]   = array[j+1];
                array[j+1] = swap;
            }
        }
        for (k = 0; k < n; k++)
            printf("%d ", array[k]);
        printf("\n");
    }

    printf("Sorted Array: ");

    for (i = 0; i < n; i++){
        printf("%d ", array[i]);
    }
    return 0;
}
